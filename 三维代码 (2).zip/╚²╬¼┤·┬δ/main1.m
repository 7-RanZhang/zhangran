% clc;
% clear,close all;

% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ͨ�Ű뾶�仯~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% m=20;
% for t=1:7
%   for k=1:m
%      [error,errorW,error33]=main(t);
%      qq(k)=error;
%      ww(k)=errorW;
%      ll(k)=Accuracy2;
%      pp(k)=error33;
%   end   
%     A1(t)=mean(qq);
%     A2(t)=mean(ww); 
%     A3(t)=mean(ll);
%     A4(t)=mean(pp);
%     y(t)=20+5*t;%%������
% end
% figure(1);
% plot(y,A1,'b*-',y,A2,'go-',y,A4,'kx-')
% xlabel('ͨ�Ű뾶��m��')
% ylabel('ƽ����λ��m��')

% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ê�ڵ�仯~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% m=20;
% for n=1:7 
%   for k=1:m
%      [error,errorW,error33]=main(n);
%      qq(k)=error;
%      ww(k)=errorW;
% %      ll(k)=Accuracy2;
%      pp(k)=error33;
%   end   
%     A1(n)=mean(qq);
%     A2(n)=mean(ww); 
% %     A3(n)=mean(ll);
%     A4(n)=mean(pp);
%     y(n)=25+5*n;%%������
% end
% figure(2);
% plot(y,A1,'b*-',y,A2,'go-',y,A4,'kx-')
% xlabel('ê�ڵ���Ŀ')
% ylabel('��λ���')

% %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~�ܽڵ�仯~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% m=20;
% for s=1:6
%   for k=1:m
%      [error,errorW,error33]=main(s);
%      qq(k)=error;
%      ww(k)=errorW;
%      pp(k)=error33;
%   end   
%     A1(s)=mean(qq);
%     A2(s)=mean(ww); 
%     A4(s)=mean(pp);
%     y(s)=200+50*s;%%������
% end
% figure(3);
% plot(y,A1,'b*-',y,A2,'go-',y,A4,'kx-')
% xlabel('�ܽڵ���Ŀ')
% ylabel('��λ���')