function[error0,error00]=HDV_Hop(NodeAmount,BeaconAmount,UNAmount,Beacon,UN,h,Distance)
h3=h((BeaconAmount+1):NodeAmount,1:BeaconAmount); %����δ֪�ڵ㵽ê�ڵ����������
d=Distance;
for i=1:3
    for j=1:(BeaconAmount-1)
      a(i,j)=Beacon(i,j)-Beacon(i,BeaconAmount);
    end
end
A=-2*(a');
for i=1:UNAmount
    for j=1:BeaconAmount-1
%         n(i,j)=1/h3(i,j);
        if(h3(i,j)==1)
         n(i,j)=1+1/max(h3(:));
        else
        n(i,j)=1/h3(i,j);
        end
    end
    s(i)=sum(n(i,:));
end
% d=d1';
 for m=1:UNAmount 
     for i=1:(BeaconAmount-1)
        
         B(i,1)=d(i,m)^2-d(BeaconAmount,m)^2-Beacon(1,i)^2+Beacon(1,BeaconAmount)^2-Beacon(2,i)^2+Beacon(2,BeaconAmount)^2-Beacon(3,i)^2+Beacon(3,BeaconAmount)^2;
     end
          
           X1=inv(A'*A)*A'*B;  %inv���溯�� 
           X(1,m)=X1(1,1);
           X(2,m)=X1(2,1); 
           X(3,m)=X1(3,1);
 end
 for i=1:UNAmount
      error0(1,i)=(((X(1,i)-UN(1,i))^2+(X(2,i)-UN(2,i))^2+(X(3,i)-UN(3,i))^2)^0.5);
 end
error00=sum(error0)/UNAmount;
% Accuracy0=error00/R; 